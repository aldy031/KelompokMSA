package org.example.rifaldytamauka;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {

    @Override
    public void start(Stage stage) throws IOException {
        // Load FXML file
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("HalamanUtama.fxml"));
        // Create the Scene with the loaded FXML content
        Scene scene = new Scene(fxmlLoader.load(), 901, 539);

        // Set the title of the window
        stage.setTitle("Hello!");

        // Set the scene to the stage
        stage.setScene(scene);

        // Show the stage
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
